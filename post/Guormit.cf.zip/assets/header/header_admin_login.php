<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <title>Admin login</title>
  <link rel="stylesheet" href="https://guormit.cf/assets/css/adminlogin2.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.2/css/all.min.css"/>
  <link rel="shortcut icon" href="https://guormit.cf/assets/logo.png" sizes="196x196" type="image/png">
  <meta property="og:title" content="ADMIN PAGE">
 <meta property="og:description" content="Admin for Guormit Archives">
<meta property="og:type" content="article">
  <meta property="og:image" content="https://guormit.cf/logo.png">
  <meta property="og:site_name" content="Guormit archives || Admin">
</head>